import time
from turtle import Screen
from player import Player
from car_manager import CarManager
from scoreboard import Scoreboard

screen = Screen()
screen.setup(width=600, height=600)
screen.tracer(0)

turtle = Player()
cars = CarManager()
score = Scoreboard()


screen.listen()
screen.onkey(turtle.up, "Up")

game_is_on = True
while game_is_on:
    time.sleep(0.1)
    screen.update()

    score.update_scoreboard()

    cars.create_car()
    cars.move_cars()

    for car in cars.all_cars:
        if car.distance(turtle) < 20:
            game_is_on = False
            score.game_over()

    if turtle.finish_line():
        turtle.go_to_start()
        cars.speed_up()
        score.increase_score()


screen.exitonclick()
